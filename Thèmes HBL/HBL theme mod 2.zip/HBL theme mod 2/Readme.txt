Homebrew Launcher theme mod create by Chronoss

To install the theme, put the .romfs file in config -> nx-hbmenu -> themes
and change the theme with the minus bouton when you are in the hbl menu

Enjoy